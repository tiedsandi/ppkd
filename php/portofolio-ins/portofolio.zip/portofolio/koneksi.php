<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "angkatan1_porto";

$conn = mysqli_connect($host, $user, $pass, $db);
